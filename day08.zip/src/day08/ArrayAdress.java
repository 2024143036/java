package day08;

public class ArrayAdress {

	public static void main(String[] args) {
		int[] arr=new int[3];
		System.out.println("arr배열이 가지고 있는값:"+arr);
		for(int i =0; i<arr.length; i++) {
			System.out.println(arr[i]);
		}
	}

}
