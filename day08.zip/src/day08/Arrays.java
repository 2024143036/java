package day08;

public class Arrays {

	public static void main(String[] args) {
		String[] strArr= {"프로그래밍","완전","너무","싫어","노는게","좋아요","별로"};
			System.out.printf("%s, %s %s!",strArr[0], strArr[1], strArr[5]);
			for(int i =0; i<strArr.length; i++) {
				System.out.print(strArr[i]+ " ");
			
		}
	}

}
