package day08;

public class Even {

	public static void main(String[] args) {
		int i =0;
		
		for(i =1; i<30; i ++) {
			if(i %2==1)
				System.out.println(i);
		}
	}

}
